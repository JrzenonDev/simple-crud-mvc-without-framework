<?php
class UserModel extends Model{
	public function Index(){
		return;
	}
}